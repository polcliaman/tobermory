﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MVP.OrderList.Presenter;

namespace MVP.OrderList.View
{
    static class main

        {
            static void Main()
            {            
                OrderListPresenter PresenterLayer = new OrderListPresenter();
                Application.Run(new OrderListView(PresenterLayer));
            }
        }
}
