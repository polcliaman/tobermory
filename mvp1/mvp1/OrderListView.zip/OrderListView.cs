﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using MVP.OrderList.Presenter;

namespace MVP.OrderList.View
{

    public partial class OrderListView : Form
    {

        public event EventHandler ViewLoaded;
        public event EventHandler AddButtonClicked;
        public event EventHandler AmendButtonClicked;
        public event EventHandler DeleteButtonClicked;

        public OrderListView(OrderListPresenter PresenterLayer)
        {
            InitializeComponent();
            PresenterLayer.SetView(this);
        }

        private void HomeView_Load(object sender, EventArgs e)
        {
           ViewLoaded?.Invoke(this, new EventArgs());
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
           AddButtonClicked?.Invoke(this, EventArgs.Empty);
        }

        private void AmendButton_Click(object sender, EventArgs e)
        {
            AmendButtonClicked?.Invoke(this, EventArgs.Empty);
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            DeleteButtonClicked?.Invoke(this, EventArgs.Empty);
        }
    }
}