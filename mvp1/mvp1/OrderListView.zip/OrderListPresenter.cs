﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using MVP.OrderList.View;

namespace MVP.OrderList.Presenter

{
    public class OrderListPresenter
    {

        private OrderListView _view;

        public void SetView(OrderListView view)
        {
            _view = view;
            _view.ViewLoaded += ViewLoaded;
            _view.AddButtonClicked += AddButtonClicked;
            _view.AmendButtonClicked += AmendButtonClicked;
            _view.DeleteButtonClicked += DeleteButtonClicked;
        }

        private async void ViewLoaded(object sender, EventArgs e)
        { 
            MessageBox.Show("In Presenter Load");        
            //await ViewLoadedImplementation();
        }

        protected void AddButtonClicked(object sender, EventArgs e)
        {
            MessageBox.Show("In Presenter Click (add)");
            //_view.AvailabilityViewIsOpen = true;
            //var availability = _viewGenerator.Create<IAvailabilityDateRangeView>();
            //availability.Show();
            //_view.AvailabilityViewIsOpen = false;

        }

        protected void AmendButtonClicked(object sender, EventArgs e)
        {
            MessageBox.Show("In Presenter Click (amend)");
            //_view.AvailabilityViewIsOpen = true;
            //var availability = _viewGenerator.Create<IAvailabilityDateRangeView>();
            //availability.Show();
            //_view.AvailabilityViewIsOpen = false;

        }

        protected void DeleteButtonClicked(object sender, EventArgs e)
        {
            MessageBox.Show("In Presenter Click (delete)");
            //_view.AvailabilityViewIsOpen = true;
            //var availability = _viewGenerator.Create<IAvailabilityDateRangeView>();
            //availability.Show();
            //_view.AvailabilityViewIsOpen = false;

        }

    }
}
